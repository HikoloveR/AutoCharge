package fakefun.ru.wings;

enum BindType {
    NONE,
    KEYBOARD,
    MOUSE
}
