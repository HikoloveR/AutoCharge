package fakefun.ru.wings;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;

public final class WingsClient implements ClientModInitializer {
    private static final int MAX_MOUSE_BUTTONS = 16;
    private static final boolean[] PREVIOUS_KEYS = new boolean[GLFW.GLFW_KEY_LAST + 1];
    private static final boolean[] PREVIOUS_MOUSE = new boolean[MAX_MOUSE_BUTTONS];

    private BindState bindState = BindConfig.load();
    private boolean waitingForBind;
    private boolean captureArmed;
    private int actionCooldownTicks;

    @Override
    public void onInitializeClient() {
        ClientSendMessageEvents.ALLOW_CHAT.register(message -> {
            if (!message.trim().startsWith(".")) {
                return true;
            }

            return handleCommand(message);
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> dispatcher.register(
                ClientCommandManager.literal("bind")
                        .then(ClientCommandManager.literal("add").executes(context -> {
                            startBindCapture();
                            return Command.SINGLE_SUCCESS;
                        }))
                        .then(ClientCommandManager.literal("clear").executes(context -> {
                            clearBind();
                            return Command.SINGLE_SUCCESS;
                        }))
        ));

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) ->
                client.execute(() -> sendClientMessage("Loaded. Use .bind add or /bind add."))
        );

        ClientTickEvents.END_CLIENT_TICK.register(this::onEndTick);
    }

    private boolean handleCommand(String rawMessage) {
        String message = rawMessage.trim();
        String lowered = message.toLowerCase(Locale.ROOT);

        if (lowered.equals(".bind add")) {
            startBindCapture();
            return false;
        }

        if (lowered.equals(".bind clear")) {
            clearBind();
            return false;
        }

        return true;
    }

    private void startBindCapture() {
        waitingForBind = true;
        captureArmed = false;
        sendClientMessage("Press any keyboard key or mouse button to set the bind.");
    }

    private void clearBind() {
        waitingForBind = false;
        captureArmed = false;
        bindState = BindState.unbound();
        BindConfig.save(bindState);
        sendClientMessage("Bind cleared.");
    }

    private void onEndTick(MinecraftClient client) {
        if (actionCooldownTicks > 0) {
            actionCooldownTicks--;
        }

        if (client.player == null || client.world == null) {
            updatePreviousInput(client);
            return;
        }

        if (waitingForBind) {
            if (tryCaptureBind(client)) {
                updatePreviousInput(client);
                return;
            }
        } else if (bindJustPressed(client) && actionCooldownTicks == 0) {
            performPearlBoost(client);
        }

        updatePreviousInput(client);
    }

    private boolean tryCaptureBind(MinecraftClient client) {
        long handle = client.getWindow().getHandle();

        if (!captureArmed) {
            captureArmed = !isAnyInputPressed(handle);
            return false;
        }

        for (int key = GLFW.GLFW_KEY_SPACE; key <= GLFW.GLFW_KEY_LAST; key++) {
            boolean pressed = GLFW.glfwGetKey(handle, key) == GLFW.GLFW_PRESS;
            if (pressed && !PREVIOUS_KEYS[key]) {
                bindState = new BindState(BindType.KEYBOARD, key);
                waitingForBind = false;
                captureArmed = false;
                BindConfig.save(bindState);
                sendClientMessage("Bind set: " + describeBind(bindState));
                return true;
            }
        }

        for (int button = 0; button < MAX_MOUSE_BUTTONS; button++) {
            boolean pressed = GLFW.glfwGetMouseButton(handle, button) == GLFW.GLFW_PRESS;
            if (pressed && !PREVIOUS_MOUSE[button]) {
                bindState = new BindState(BindType.MOUSE, button);
                waitingForBind = false;
                captureArmed = false;
                BindConfig.save(bindState);
                sendClientMessage("Bind set: " + describeBind(bindState));
                return true;
            }
        }

        return false;
    }

    private boolean bindJustPressed(MinecraftClient client) {
        if (!bindState.isBound() || client.currentScreen != null) {
            return false;
        }

        long handle = client.getWindow().getHandle();
        return switch (bindState.type()) {
            case KEYBOARD -> {
                boolean pressed = GLFW.glfwGetKey(handle, bindState.code()) == GLFW.GLFW_PRESS;
                yield pressed && !PREVIOUS_KEYS[bindState.code()];
            }
            case MOUSE -> {
                boolean pressed = GLFW.glfwGetMouseButton(handle, bindState.code()) == GLFW.GLFW_PRESS;
                yield pressed && !PREVIOUS_MOUSE[bindState.code()];
            }
            default -> false;
        };
    }

    private void performPearlBoost(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null || player.getAbilities().flying) {
            return;
        }

        int pearlSlot = findHotbarSlot(player, Items.ENDER_PEARL);
        int chargeSlot = findHotbarSlot(player, Items.WIND_CHARGE);

        if (pearlSlot == -1 || chargeSlot == -1) {
            if (pearlSlot == -1 && chargeSlot == -1) {
                sendClientMessage("No ender pearl and wind charge found in the hotbar.");
            } else if (pearlSlot == -1) {
                sendClientMessage("No ender pearl found in the hotbar.");
            } else {
                sendClientMessage("No wind charge found in the hotbar.");
            }
            actionCooldownTicks = 10;
            return;
        }

        int oldSlot = player.getInventory().selectedSlot;
        useHotbarSlot(client, player, pearlSlot);
        useHotbarSlot(client, player, chargeSlot);
        selectHotbarSlot(player, oldSlot);
        actionCooldownTicks = 4;
    }

    private void useHotbarSlot(MinecraftClient client, ClientPlayerEntity player, int slot) {
        selectHotbarSlot(player, slot);
        client.interactionManager.interactItem(player, Hand.MAIN_HAND);
        player.swingHand(Hand.MAIN_HAND);
    }

    private void selectHotbarSlot(ClientPlayerEntity player, int slot) {
        player.getInventory().selectedSlot = slot;
        player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(slot));
    }

    private int findHotbarSlot(ClientPlayerEntity player, Item item) {
        for (int slot = 0; slot < 9; slot++) {
            if (player.getInventory().getStack(slot).isOf(item)) {
                return slot;
            }
        }
        return -1;
    }

    private void updatePreviousInput(MinecraftClient client) {
        long handle = client.getWindow().getHandle();

        for (int key = GLFW.GLFW_KEY_SPACE; key <= GLFW.GLFW_KEY_LAST; key++) {
            PREVIOUS_KEYS[key] = GLFW.glfwGetKey(handle, key) == GLFW.GLFW_PRESS;
        }

        for (int button = 0; button < MAX_MOUSE_BUTTONS; button++) {
            PREVIOUS_MOUSE[button] = GLFW.glfwGetMouseButton(handle, button) == GLFW.GLFW_PRESS;
        }
    }

    private boolean isAnyInputPressed(long handle) {
        for (int key = GLFW.GLFW_KEY_SPACE; key <= GLFW.GLFW_KEY_LAST; key++) {
            if (GLFW.glfwGetKey(handle, key) == GLFW.GLFW_PRESS) {
                return true;
            }
        }

        for (int button = 0; button < MAX_MOUSE_BUTTONS; button++) {
            if (GLFW.glfwGetMouseButton(handle, button) == GLFW.GLFW_PRESS) {
                return true;
            }
        }

        return false;
    }

    private String describeBind(BindState state) {
        return switch (state.type()) {
            case KEYBOARD -> GLFW.glfwGetKeyName(state.code(), 0) != null
                    ? GLFW.glfwGetKeyName(state.code(), 0).toUpperCase(Locale.ROOT)
                    : "KEY_" + state.code();
            case MOUSE -> "MOUSE_" + (state.code() + 1);
            default -> "NONE";
        };
    }

    private void sendClientMessage(String message) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            client.player.sendMessage(Text.literal("[Wings] " + message), false);
        }
    }
}
